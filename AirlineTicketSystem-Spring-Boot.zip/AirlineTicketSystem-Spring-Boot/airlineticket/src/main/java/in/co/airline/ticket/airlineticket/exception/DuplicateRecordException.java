package in.co.airline.ticket.airlineticket.exception;



public class DuplicateRecordException  extends Exception
{
	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
